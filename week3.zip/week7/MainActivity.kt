package com.example.week7

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AppUi()
            navigation()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
    }

}

@Composable
fun AppUi() {
    val navController = rememberNavController()
    NavHost(navController, startDestination = "mainScreen") {
        composable("mainScreen"){
            MainScreen(navController)
        }
        composable("anotherScreen/{message}"){ backStackEntry ->
            val message = backStackEntry.arguments?.getString("message")
            AnotherScreen(navController, message)
        }
    }

}

