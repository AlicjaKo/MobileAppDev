import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileForm() {
    var name by rememberSaveable { mutableStateOf("") }
    var count by rememberSaveable { mutableStateOf(0) }
    var timer by rememberSaveable {mutableStateOf(0)}
    var isRunning by remember { mutableStateOf(true) }

    val lifecycleOwner = LocalLifecycleOwner.current

    // Lifecycle observer to pause and resume timer
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE -> isRunning = false
                Lifecycle.Event.ON_RESUME -> isRunning = true
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Timer logic
    LaunchedEffect(isRunning) {
        while (isRunning) {
            delay(1000)
            timer++
        }
    }




    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Hello, $name!",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF6200EE)
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Enter your name") },
            singleLine = true,
            keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Text),
            colors = TextFieldDefaults.outlinedTextFieldColors(
                focusedBorderColor = Color(0xFF6200EE),
                unfocusedBorderColor = Color.Gray,
                cursorColor = Color(0xFF6200EE)
            )
        )

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "Counter: $count",
            fontSize = 24.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color.DarkGray
        )

        Spacer(modifier = Modifier.height(16.dp))

        Row {
            Button(
                onClick = { count++ },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF03DAC5))
            ) {
                Text("Increment", fontSize = 16.sp)
            }

            Spacer(modifier = Modifier.width(16.dp))

            Button(
                onClick = { count = 0 },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE53935))
            ) {
                Text("Reset", fontSize = 16.sp, color = Color.White)
            }

        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Timer: $timer",
            fontSize = 24.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color.DarkGray
        )

    }
}

@Preview(showBackground = true)
@Composable
fun PreviewProfileForm() {
    ProfileForm()
}
