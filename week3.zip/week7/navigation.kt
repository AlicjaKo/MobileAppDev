package com.example.week7

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

sealed class Screens(val screen: String) {
    object MainScreen : Screens("main")
    object Settings : Screens("settings")
    object Profile : Screens("profile")
}



@Composable
fun navigation() {
    val navigationController = rememberNavController()
    val selected = remember {
        mutableStateOf(Icons.Filled.Home)
    }

    Scaffold(
        bottomBar = {
            BottomAppBar(
                containerColor = Color.Gray
            ) {
                IconButton(
                    onClick = {
                        selected.value = Icons.Filled.Home
                        navigationController.navigate(Screens.MainScreen.screen) {
                            popUpTo(0)
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Home,
                        contentDescription = "Home",
                        modifier = Modifier.size(26.dp),
                        tint = if (selected.value == Icons.Filled.Home) Color.White else Color.DarkGray
                    )
                }
                IconButton(
                    onClick = {
                        selected.value = Icons.Filled.Settings
                        navigationController.navigate(Screens.Settings.screen) {
                            popUpTo(0)
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Settings,
                        contentDescription = "Settings",
                        modifier = Modifier.size(26.dp),
                        tint = if (selected.value == Icons.Filled.Settings) Color.White else Color.DarkGray
                    )
                }
                IconButton(
                    onClick = {
                        selected.value = Icons.Filled.Person
                        navigationController.navigate(Screens.Profile.screen) {
                            popUpTo(0)
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Person,
                        contentDescription = "Profile",
                        modifier = Modifier.size(26.dp),
                        tint = if (selected.value == Icons.Filled.Person) Color.White else Color.DarkGray
                    )
                }
            }
        },
        content = { paddingValues ->
            NavHost(
                navController = navigationController,
                startDestination = Screens.MainScreen.screen,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues) // Apply padding here!
            ) {
                composable(Screens.MainScreen.screen) {
                    Text("Main Screen")
                }
                composable(Screens.Settings.screen) {
                    Text("Settings Screen")
                }
                composable(Screens.Profile.screen) {
                    Text("Profile Screen")
                }
            }
        }
    )
}