package com.example.week6

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CustomScreen()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Preview
@Composable
fun CustomScreen() {
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = stringResource(R.string.my_app)) },
                colors = TopAppBarDefaults.mediumTopAppBarColors(containerColor = Color(0.4f, 0.1f, 0.5f), titleContentColor = Color.White)
            )
        },
        bottomBar = {
            BottomAppBar(
                containerColor = Color(0.4f, 0.1f, 0.5f)
            ) {
                Text(text = stringResource(R.string.made_by_alicja_kosak), modifier = Modifier.padding(16.dp), color = Color.White)
            }
        },
        floatingActionButton = {
            FloatingActionButton(onClick = {
                Toast.makeText(context,
                    context.getString(R.string.floating_action_button_clicked), Toast.LENGTH_SHORT).show()
            }) {
                Text("+")
            }
        },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.LightGray)
                .padding(innerPadding),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Spacer(modifier = Modifier.height(5.dp))
            InfoCard(stringResource(R.string.hello_tamk),
                stringResource(R.string.this_is_my_reusable_component))
            Button(
                onClick = {
                    Toast.makeText(context,
                        context.getString(R.string.button_clicked), Toast.LENGTH_SHORT).show()
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color.Gray)
            ) {
                Text(
                    stringResource(R.string.click_me),
                    fontSize = 20.sp,
                    color = Color.White
                )
            }
            Image(
                painter = painterResource(id = R.drawable.labrador_puppy_happy),
                contentDescription = "Labrador Happy Puppy",
                modifier = Modifier.size(150.dp) // Adjust size as needed
            )
            LoginForm()
            InfoCard(stringResource(R.string.creator), stringResource(R.string.infocard_author))

        }
    }
}
