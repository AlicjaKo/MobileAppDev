import 'package:flutter/material.dart';
import 'screens/home.dart';
import 'database/database.dart';
import 'component/recipe_com.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final dbService = DatabaseService();
  await dbService.insertRecipe(Recipe(title: 'Spaghetti', description: 'Delicious Italian pasta with tomato sauce.'));
  await dbService.insertRecipe(Recipe(title: 'Tacos', description: 'Mexican tacos with beef, lettuce, and cheese.'));
  await dbService.insertRecipe(Recipe(title: 'Pancakes', description: 'Fluffy pancakes served with syrup and butter.'));

  final recipes = await dbService.getRecipes();
  print('Recipes in database: ${recipes.map((r) => r.title).toList()}');

  runApp(RecipeApp());
}

class RecipeApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Recipe App',
      theme: ThemeData(
        primaryColor: Colors.yellow,
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.yellow,
          foregroundColor: Colors.black,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.yellow,
            foregroundColor: Colors.black,
          ),
        ),
        scaffoldBackgroundColor: Colors.white,
      ),
      home: HomeScreen(),
    );
  }
}