import 'package:flutter/material.dart';
import '../component/recipe_com.dart';
import '../database/database.dart';
import 'recipe.dart';

class BrowseScreen extends StatefulWidget {
  @override
  _BrowseScreenState createState() => _BrowseScreenState();
}

class _BrowseScreenState extends State<BrowseScreen> {
  final DatabaseService _databaseService = DatabaseService();
  List<Recipe> _recipes = [];

  @override
  void initState() {
    super.initState();
    _fetchRecipes();
  }

  Future<void> _fetchRecipes() async {
    final recipes = await _databaseService.getRecipes();
    setState(() {
      _recipes = recipes;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Browse Recipes')),
      body: _recipes.isEmpty
          ? Center(child: Text('No recipes available.'))
          : ListView.builder(
              itemCount: _recipes.length,
              itemBuilder: (context, index) {
                final recipe = _recipes[index];
                return ListTile(
                  title: Text(recipe.title),
                  subtitle: Text(recipe.description.split('.').first),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => RecipeDetailScreen(
                          title: recipe.title,
                          description: recipe.description,
                        ),
                      ),
                    );
                  },
                );
              },
            ),
    );
  }
}