import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../component/recipe_com.dart';

class DatabaseService {
  Future<void> insertRecipe(Recipe recipe) async {
    final prefs = await SharedPreferences.getInstance();
    final recipes = await getRecipes();
    recipes.add(recipe);
    final recipesJson = jsonEncode(recipes.map((r) => r.toMap()).toList());
    await prefs.setString('recipes', recipesJson);
  }

  Future<List<Recipe>> getRecipes() async {
    final prefs = await SharedPreferences.getInstance();
    final recipesJson = prefs.getString('recipes');
    if (recipesJson == null) return [];
    final List<dynamic> recipesList = jsonDecode(recipesJson);
    return recipesList.map((e) => Recipe.fromMap(e)).toList();
  }

  Future<void> deleteRecipe(String title) async {
    final prefs = await SharedPreferences.getInstance();
    final recipes = await getRecipes();
    recipes.removeWhere((r) => r.title == title);
    final recipesJson = jsonEncode(recipes.map((r) => r.toMap()).toList());
    await prefs.setString('recipes', recipesJson);
  }
}